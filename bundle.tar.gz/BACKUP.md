# Backup & disaster recovery operations

**Not enabled automatically.** Installation or deployment must include a scheduler, suitable storage, monitoring, and a completed restore test before any live financial data is entered.

## Supported methods

- SQLite: consistent online backup via Python's `sqlite3.Connection.backup()`, compressed to `atlas-*.sqlite3.gz`, and checked with `PRAGMA integrity_check`.
- PostgreSQL: `pg_dump --format=custom` via PostgreSQL client utility. Install a compatible `pg_dump` on the job runner. See `scripts/backup.py`.
- Every backup gets a SHA-256 checksum companion file.
- Default local retention is 30 days; configure `BACKUP_RETENTION_DAYS` as required.
- Store backups in a location separate from the application/database server. `BACKUP_DEST` defaults to local `./backups` **for development only**.

## Schedule

On a Unix/Linux host, choose a protected system account and environment-file access controlled to that account. An example daily 2 AM job:

```cron
0 2 * * * cd /srv/atlas && /srv/atlas/.venv/bin/python scripts/backup.py >> /var/log/atlas-backup.log 2>&1
```

For hosted deployment, use a dedicated managed scheduled job or equivalent. Configure `DATABASE_URL`, `BACKUP_DEST`, retention, and failure notifications in the hosting platform.

## Verify restore readiness

Run `python scripts/check_backup.py /path/to/atlas-DATE.sqlite3.gz` on each SQLite backup, and monthly perform an actual restore in an isolated environment. For PostgreSQL, use `pg_restore --list backup.postgres.dump` and restore it into a **separate new test database**, then inspect journal totals and login/application behavior.

Do not replace the live database while testing. Before an actual production restore, pause web writes, preserve the damaged database separately, confirm the backup checksum and restore timestamp, then follow a signed-off recovery plan.

## Critical limitations

A backup may lose any writes made since its snapshot. A scheduled job can fail or miss a day. Check and alert on missing or failed backups. Local-only copies do **not** protect against server loss. Enable offsite backup encryption, access controls, monitoring, backup success alerts, and restore drills before handover.
