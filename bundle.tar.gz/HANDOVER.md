# Client Handover | Atlas Ledger

## Client software package

**Proposed use:** Shipping, Skybox, local courier, freight forwarding, customs brokerage, import/export and transportation accounting.

Atlas Ledger is a responsive accounting and operations web application for a single business. No dummy customer accounts, fabricated receipts, sample invoices, fake revenue, supplier transactions, employees or payroll have been stored. On first launch, the administrator supplies the company's real business identity and approved records.

## Included working areas

1. **Finance overview** — posted income, expenses, profitability, receivables, cash and activity.
2. **Invoices** — individually generated customer invoices, PDF downloads, customer balances, partial/complete payments.
3. **Skybox batch billing** — bulk generate up to 1,000 customer invoices from a validated CSV upload.
4. **Class/division tracking** — separately track Skybox, Courier, Transportation and any other client-defined division.
5. **Multi-currency invoicing and costs** — transactions in TTD, USD, EUR, GBP and CAD; historical manual FX booking rates; realized FX differences on payments.
6. **Suppliers and expenses** — purchase bills, customs duties, freight costs, operating expenses and payment tracking.
7. **Historical records** — entering dated invoices, bills, journals and payroll as far back as 1900.
8. **Employee and payroll records** — employee management, gross/net wages and manual withholding entries.
9. **Financial reporting** — income statement, statement of financial position summary, trial balance, cash movements, division profitability and CSV exports.
10. **Staff access and controls** — individual secure logins, user roles and audit logs.
11. **Backup tooling** — scripts to create and verify database backups. Hosting provider scheduling and off-site replication are required before claiming the feature is live.

## Operating model

- Runs as a private web app on a server or local computer.
- For employees on different devices, hosting and HTTPS configuration are required.
- Reporting base currency is TTD.
- Recorded financial numbers reflect only genuine transactions the business enters.
- The accounting engine uses double-entry base-currency journals, not editable totals or generated demo charts.

## Important outstanding steps

This is a **handover build**, not a representation that the client's live system is already operating. The business owner must approve its name, workflows and internal permissions; arrange hosting/storage and backup operations; provide real financial data; and approve compliance and accuracy tests. If the customer needs automatic payroll deductions, bank feeds, customs integrations, online payments, inventory, invoice emails or regulatory filings, those are **additional development tasks**, not active features in this delivery.

## Recommended order of handover

First review the UI and feature scope. Next configure client infrastructure, admin access, backup schedules and monitoring. Then pilot the client's own invoice-to-payment, supplier-expense and report workflows with accountant oversight. Finally reconcile opening balances and go live only once the owner has signed off.
