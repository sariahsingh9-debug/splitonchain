# ATLAS LEDGER
## Client accounting & logistics management software

**Deliverable:** A working, locally tested business accounting web application, packaged without fictitious customers, transactions, employees, vendors, or financial figures. This is source code and a functional application. **It is not a hosted, deployed or independently certified accounting service.**

The client creates a real administrator account on first launch and adds the company's real financial records. The default chart of accounts and numbering sequences are system configuration, **not sample business data**.

![Atlas Ledger blank-workspace preview](assets/preview-desktop.png)

### What is included

| Module | Implemented capabilities |
|---|---|
| Financial dashboard | Live posted revenue, expenses, profit, cash and receivables; six-month graph; empty states |
| Customers and suppliers | Create, edit, categorize and search contact records |
| Invoices | Draft, issue, PDF export, partial/full payment recording, tracking, void-with-reversal for unpaid invoices |
| Batch Skybox billing | Validate a CSV file and issue 1–1,000 customer invoices with atomic journal postings |
| Division/class tracking | Create business divisions; assign transactions; compare revenue, expense and profits |
| Foreign currency | TTD / USD / EUR / GBP / CAD documents with entered historic conversion rate and posted TTD-equivalent ledger entries, settlement FX differences |
| Supplier bills and expenses | Post payable and category, track due dates, allocate divisions, record supplier payments; customs/shipping categories |
| Historical records | Backdated invoices, expenses, payroll and manually posted opening journals from 1900 onwards |
| Payroll records | Employee directory, gross pay, manually entered NIS/PAYE/Health Surcharge/other deductions, net salary and payment postings |
| Financial reports | Profit-and-loss, balance sheet overview, trial balance, division profits, cash movement summary, CSV exports |
| General ledger | Balanced double-entry journal, date/account filters and detailed export, opening/adjusting manual journals |
| Access controls | Password-hashed users, admin/accountant/staff/viewer roles, session-based login, CSRF protection, audit logs, deactivate other users |
| Backups | Backup + integrity-check scripts with PostgreSQL and SQLite support; scheduling and off-site replication must be configured |
| Interface | Responsive desktop/mobile design, professional PDF invoices, clean first-run onboarding |

### What is *not* automatically included

Actual bank feeds, bank reconciliation matching, automatic invoice emailing, online card acceptance, inventory management, shipment tracking, customs-declaration APIs, payroll statutory rate calculation/filing, automated VAT returns, document-level permissions, multi-company consolidation, fiscal period locks, historic FX market feeds, and production monitoring are **not implemented**. These require separately specified integrations and acceptance testing. Product scope can be expanded.

## Getting started (Windows)

1. Extract the ZIP to a private location on the Windows computer.
2. Install Python 3.11 or 3.12 from python.org, including the **Add Python to PATH** option.
3. Open Command Prompt inside the extracted `atlas-ledger` directory.
4. Set a strong first-time setup key and a separate random session key. Example commands (replace both values):

   ```bat
   set SETUP_TOKEN=replace-with-a-unique-private-setup-code
   set SESSION_SECRET=replace-with-a-long-random-secret-at-least-64-chars
   start-windows.bat
   ```

5. Wait for the server to start; open **http://127.0.0.1:8000** in your browser.
6. Enter the setup key, company name, admin name, email and a 12+ character password.
7. Open Settings to fill in official business details, then create your real business divisions and contacts.
8. Close the Command Prompt to stop the local server. Local access is intended for setup or acceptance testing, not a company-wide production installation.

## Linux / macOS local

```bash
cd atlas-ledger
export SETUP_TOKEN='replace-with-a-strong-setup-key'
export SESSION_SECRET='replace-with-a-different-random-64-character-secret'
./start-local.sh
# Go to http://127.0.0.1:8000
```

## Production environment

**For client-wide access from phones and computers, deploy the software to a secured HTTPS host with PostgreSQL**. Do not expose the local SQLite example setup publicly.

Required secrets and settings:

- `DATABASE_URL`: Managed PostgreSQL URI, for example `postgresql+psycopg://...`.
- `SESSION_SECRET`: A securely generated, persistent random secret.
- `SETUP_TOKEN`: Separate, securely generated first-time setup key. Rotate/disable after provisioning and keep a secure copy in the installation records.
- `COOKIE_SECURE=1`: Enforce HTTPS-only session cookies.
- `BACKUP_DEST`: Protected backup destination on a **different storage system** from database and web node.
- `BACKUP_RETENTION_DAYS`: Default 30; retention must follow the company's policy.

The included `Dockerfile` runs the app as a non-root user. You must provision managed Postgres, DNS, valid TLS, data-processing policies, external backup storage, monitoring and access controls in the hosting platform. The included **`/health`** route checks database reachability.

### First-launch note

A previously initialized database cannot return to `/setup` unless intentionally migrated/reprovisioned. Do **not** delete a production database to re-run setup. Admin users can be managed in Settings. Do not share the setup token with ordinary employees.

### Database schema management

On initial installation, SQLAlchemy creates required tables and a standard chart of accounts. Existing tables are **not migrated** by code changes: require a reviewed migration plan (for example, Alembic) for future software upgrades. Never overwrite production data during updates.

## How this accounting system posts records

- **Issue invoice:** debit receivables; credit service revenue and sales VAT liability if configured.
- **Receive invoice payment:** debit cash/bank; credit receivables; post realized exchange gain/loss where the settlement rate differs.
- **Record supplier expense:** debit expense and separately configured recoverable VAT, credit accounts payable.
- **Pay supplier bill:** debit payable; credit cash/bank; post realized foreign exchange differences if applicable.
- **Post payroll:** debit gross salaries expense; credit payroll net liability and withholding liability.
- **Pay net payroll:** debit payroll net liability, credit cash/bank.
- **Manual journal:** accept only equal positive debit and credit totals, up to six lines.

Each document and settlement stores original-currency minor units as integers, and FX rates are stored as decimal strings. Every journal balances in the **TTD base currency**. All foreign rate entries are supplied by an authorized user; this software does not fetch historical rates on its own.

### Correcting mistakes

Draft invoices can be voided. Issued but entirely unpaid invoices can be voided with a separately dated reversal journal; issued financial journal entries are not deleted. For paid invoices or other posted accounting records, use an accountant-reviewed correcting journal; this release does not implement linked credit notes or formal adjustment workflows.

### Historic information

Enter previous financial activity using historical dates. For a former accounting system, an accountant should determine correct opening balances, outstanding receivables/payables, cutoff date and recognized income so you do **not** double-count old transactions. A historical report is only as complete as the original data that was entered.

### Skybox batch CSV

From the Skybox batch page, download the CSV template, which contains these headers:

```
customer_email,division_code,shipment_reference,description,amount,currency,fx_rate,invoice_date,due_date
```

Every row creates an individual invoice and its journal entry; a batch may have up to 1,000 rows, within 2 MB. All `customer_email` entries must exist in Customers. Divisions must exist and match `division_code`. `fx_rate` means **TTD per one unit of the document currency**, and should be `1` for TTD transactions. Preview the file, then reselect the exact same file and confirm. The entire batch rolls back if posting fails. This release does not combine multiple CSV rows into one invoice per customer or email invoices automatically.

## Security and backup responsibilities

The application includes authentication, roles, CSRF protections, audit history, password hashing, HTTP security headers and database-backed records. It has **not** been externally penetration tested. Client deployment must include:

- TLS/HTTPS, secure secret storage, least-privilege infrastructure credentials, multi-factor access at the hosting provider, rate limits or WAF on the public reverse proxy, and tested incident response.
- Regular restore-tested, encrypted, geographically separated/offsite backups (see `BACKUP.md`).
- Monitoring, update and dependency policies, storage capacity and operational uptime checks.
- Accountant review of VAT, NIS, PAYE, Health Surcharge and other Trinidad & Tobago compliance assumptions.
- Data migration sign-off and signed client user acceptance tests on realistic, **client-provided** records.

## Acceptance testing

With required dependencies installed:

```bash
python -m pytest tests/test_flow.py -q
```

The test suite creates its **own disposable temporary database**, never shipping sample data to the customer's workspace. It covers initial setup, class divisions, historical USD invoice journal, partial/full FX payments, PDF invoice, supplier bills, payroll postings, batch file preview/issuance (including 120-row volume), trial balance, opening journal, billing snapshot preservation, role/CSRF cases and balanced double-entry controls.

## Client handover checklist

A handover is complete only after all of these are signed off:

- [ ] Business trading name and contact details confirmed.
- [ ] Company data/privacy and accounting requirements verified by client.
- [ ] Business divisions, payment terms, VAT treatment and employee role access approved.
- [ ] PostgreSQL, HTTPS hostname, secrets and administrator created in **client-controlled hosting**.
- [ ] Backups scheduled, replicated offsite, monitored, and restoration tested.
- [ ] Historical transactions and opening balances reconciled with accountant.
- [ ] Bank account balances, statement exports, P&L, balance sheet and FX reporting checked.
- [ ] Payroll deduction treatment and statutory obligations signed off by Trinidad accountant.
- [ ] Real, client-provided transactions tested; no fictitious data transferred.
- [ ] Written agreement on maintenance, support, bugs, custom features and ownership.

**Delivery status:** Initial functional build completed and automated application tests passed. Production deployment, real business setup, accounting certification and live client acceptance are **pending**.
