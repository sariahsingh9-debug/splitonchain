"""Atlas Ledger: single-company accounting, invoicing and logistics operations.

Amounts are recorded as integer minor units (cents), while exchange rates use Decimal.
The immutable journal is the accounting source of truth. No financial demo data is seeded.
"""
import os, re, io, csv, json, secrets, hmac, logging, hashlib
from xml.sax.saxutils import escape as xml_escape
from datetime import date, timedelta, datetime
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
from collections import defaultdict
from urllib.parse import quote
from contextlib import contextmanager
from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, StreamingResponse, Response, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy import func, desc, select, and_, or_, text
from sqlalchemy.exc import IntegrityError
from argon2 import PasswordHasher, exceptions as argonexc
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib.enums import TA_RIGHT
from models import (SessionLocal, initialize, Setting, User, Division, Contact, Account, Invoice, InvoiceLine,
                    Expense, Payment, Journal, JournalLine, Employee, Payroll, Audit, NumberSequence)

ROOT = os.path.dirname(os.path.abspath(__file__))
logging.basicConfig(level=logging.INFO)
log = logging.getLogger('atlas')
SESSION_KEY = os.getenv('SESSION_SECRET') or secrets.token_urlsafe(48)
if not os.getenv('SESSION_SECRET'): log.warning('SESSION_SECRET not set: sessions reset on server restart; configure before deployment.')
app = FastAPI(title='Atlas Ledger', docs_url=None, redoc_url=None, openapi_url=None)
app.mount('/static', StaticFiles(directory=os.path.join(ROOT,'static')), name='static')
templates = Jinja2Templates(directory=os.path.join(ROOT,'templates'))
ph = PasswordHasher()

# Fixed point arithmetic: never store floating-point financial amounts.
D = lambda n: Decimal(str(n))
Q = Decimal('0.01')

def money_cents(v, *, allow_zero=False):
    try:
        n = D(str(v).replace(',','').strip())
        if not n.is_finite() or n < 0 or (not allow_zero and n == 0): raise ValueError()
        return int((n * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    except (InvalidOperation, ValueError, TypeError): raise ValueError('Enter a valid positive amount.')

def cents(n): return f'{D(n or 0)/100:,.2f}'
def fx_value(v, currency, base='TTD'):
    if currency == base: return D('1')
    try:
        r = D(str(v).strip())
        if not r.is_finite() or r <= 0 or r > D('1000000'): raise ValueError()
        return r
    except (InvalidOperation, ValueError): raise ValueError('Enter a valid positive exchange rate.')

def base_cents(n, rate): return int((D(n)*D(rate)).quantize(Decimal('1'),rounding=ROUND_HALF_UP))

def today(): return date.today()
def parse_date(v):
    try:
        d = date.fromisoformat(v)
        if d.year < 1900 or d > date.today() + timedelta(days=3650): raise ValueError()
        return d
    except: raise ValueError('Enter a valid date (1900 or later).')

def month_window(period):
    try:
        y,m = map(int, period.split('-')); assert 1900 <= y <= 9999 and 1 <= m <= 12
        return date(y,m,1), date(y+1,1,1) if m == 12 else date(y,m+1,1)
    except: raise ValueError('Enter a valid payroll month.')

def account(db, code):
    a = db.query(Account).filter_by(code=code).first()
    if not a: raise ValueError('An essential accounting account is missing.')
    return a.id

def journal(db, when, description, source_type, source_id, lines, user_id=None, reversal_of=None):
    """Post balanced base-currency debit and credit journal rows transactionally."""
    deb = sum(int(x[1]) for x in lines); cred = sum(int(x[2]) for x in lines)
    if not lines or deb != cred or deb <= 0: raise ValueError(f'Unbalanced journal: debit={deb}, credit={cred}.')
    if any(x[1] < 0 or x[2] < 0 or (x[1] and x[2]) for x in lines): raise ValueError('Invalid journal line.')
    j = Journal(entry_date=when, reference='TMP-'+secrets.token_hex(12), description=description,
                source_type=source_type, source_id=source_id, created_by=user_id, reversal_of=reversal_of)
    db.add(j); db.flush(); j.reference=f'JE-{j.id:07d}'
    for acc, debit, credit, division in lines:
        db.add(JournalLine(journal_id=j.id,account_id=acc,debit_cents=debit,credit_cents=credit,division_id=division))
    db.flush(); return j

def audit(db, request, action, subject, subject_id=None, summary=''):
    u=request.state.user
    db.add(Audit(user_id=u.id if u else None,action=action,subject=subject,subject_id=subject_id,summary=str(summary)[:500]))

def next_number(db, key, prefix):
    # Update and lock the sequence row on PostgreSQL; SQLite serializes writes.
    row=db.query(NumberSequence).filter_by(key=key).with_for_update().first()
    if not row:
        row=NumberSequence(key=key,value=0); db.add(row); db.flush()
    row.value+=1
    return f'{prefix}-{row.value:06d}'

def get_setting(db): return db.query(Setting).first()

def flash(request, message, kind='info'):
    request.session['flash']={'message':str(message),'kind':kind}

def redirect(url): return RedirectResponse(url, status_code=303)

def csrf_token(request):
    if not request.session.get('csrf'): request.session['csrf']=secrets.token_urlsafe(32)
    return request.session['csrf']

def check_csrf(request, token):
    if not token or not hmac.compare_digest(request.session.get('csrf',''),str(token)):
        raise HTTPException(403, 'Session expired. Refresh this page and try again.')

def render(request, name, **kwargs):
    with SessionLocal() as db:
        settings = get_setting(db)
    ctx={'request':request,'setting':settings,'user':getattr(request.state,'user',None),
         'csrf':csrf_token(request),'flash':request.session.pop('flash',None),'today':today().isoformat(),
         'cents':cents, 'nav':kwargs.pop('nav','dashboard'), **kwargs}
    return templates.TemplateResponse(request, name,ctx)

def require(request, *roles):
    if request.state.user is None: raise HTTPException(401,'Sign in required')
    if roles and request.state.user.role not in roles: raise HTTPException(403,'You do not have permission for this action.')
    return request.state.user

@app.middleware('http')
async def auth_gate(request, call_next):
    request.state.user = None
    path = request.url.path
    if path.startswith('/static/') or path == '/health': return await call_next(request)
    with SessionLocal() as db:
        setting=get_setting(db)
        if not setting and path not in ('/setup','/health'):
            return redirect('/setup')
        if setting and path == '/setup': return redirect('/login')
        uid=request.session.get('user_id')
        if uid:
            u=db.get(User,uid)
            if u and u.active: request.state.user=u
    if setting and not request.state.user and path not in ('/login',): return redirect('/login')
    response = await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Cache-Control']='no-store'
    response.headers['Content-Security-Policy'] = ("default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'")
    if os.getenv('COOKIE_SECURE','0')=='1':response.headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains'
    return response

@app.get('/health')
def health():
    try:
        with SessionLocal() as db:db.execute(text('SELECT 1')).scalar_one()
        return {'status':'ok','database':'reachable'}
    except Exception:
        raise HTTPException(503,'Database unavailable')

@app.exception_handler(HTTPException)
async def handled_error(request, e):
    if e.status_code == 401: return redirect('/login')
    return HTMLResponse(f'<html><body style="font:16px system-ui;max-width:580px;margin:100px auto"><h1>{e.status_code}</h1><p>{e.detail}</p><a href="/">Return to dashboard</a></body></html>',status_code=e.status_code)

@app.get('/setup')
def setup_page(request:Request): return render(request,'auth.html',mode='setup',nav='setup')

@app.post('/setup')
def setup_save(request:Request, csrf:str=Form(...), setup_token:str=Form(...),company_name:str=Form(...),
               full_name:str=Form(...),email:str=Form(...),password:str=Form(...)):
    check_csrf(request,csrf)
    expected=os.getenv('SETUP_TOKEN','')
    if not expected or not hmac.compare_digest(setup_token,expected):
        flash(request,'Setup key missing or incorrect. Your installer must set SETUP_TOKEN.','error'); return redirect('/setup')
    if len(password)<12 or len(company_name.strip())<2 or '@' not in email: 
        flash(request,'Enter a company name, valid email and a password of at least 12 characters.','error'); return redirect('/setup')
    with SessionLocal() as db:
        if get_setting(db): return redirect('/login')
        db.add(Setting(company_name=company_name.strip(),base_currency='TTD'))
        u=User(full_name=full_name.strip(),email=email.strip().lower(),password_hash=ph.hash(password),role='admin'); db.add(u)
        db.commit()
        request.session.clear(); request.session['user_id']=u.id
    flash(request,'Workspace created. Add business divisions, customers and opening records to get started.','success')
    return redirect('/')

FAILED={}
@app.get('/login')
def login_page(request:Request): return render(request,'auth.html',mode='login',nav='login')
@app.post('/login')
def login(request:Request,csrf:str=Form(...),email:str=Form(...),password:str=Form(...)):
    check_csrf(request,csrf)
    ident=(request.client.host if request.client else 'local',email.lower().strip())
    attempts=FAILED.get(ident,[]); now=datetime.utcnow().timestamp()
    attempts=[x for x in attempts if now-x<900]
    if len(attempts)>=7: flash(request,'Too many attempts. Try again in 15 minutes.','error'); return redirect('/login')
    with SessionLocal() as db: u=db.query(User).filter_by(email=email.lower().strip(),active=True).first()
    valid=False
    if u:
        try: valid=ph.verify(u.password_hash,password)
        except (argonexc.VerifyMismatchError,argonexc.VerificationError): pass
    if not valid:
        attempts.append(now);FAILED[ident]=attempts
        flash(request,'Invalid email or password.','error');return redirect('/login')
    FAILED.pop(ident,None);request.session.clear();request.session['user_id']=u.id
    return redirect('/')
@app.post('/logout')
def logout(request:Request,csrf:str=Form(...)):
    check_csrf(request,csrf);request.session.clear();return redirect('/login')

# Dashboard numbers derive exclusively from actual posted records.
def journal_sum(db, code, through=None, division=None):
    q=db.query(func.coalesce(func.sum(JournalLine.debit_cents),0),func.coalesce(func.sum(JournalLine.credit_cents),0)).join(Journal, Journal.id==JournalLine.journal_id).join(Account, Account.id==JournalLine.account_id).filter(Account.code==code)
    if through: q=q.filter(Journal.entry_date<=through)
    if division: q=q.filter(JournalLine.division_id==division)
    return q.first()

def account_balances(db, start=None, end=None, division=None):
    q=db.query(Account.id,Account.code,Account.name,Account.kind,func.coalesce(func.sum(JournalLine.debit_cents),0),func.coalesce(func.sum(JournalLine.credit_cents),0)).outerjoin(JournalLine,Account.id==JournalLine.account_id).outerjoin(Journal,Journal.id==JournalLine.journal_id)
    if start: q=q.filter(or_(Journal.id==None,Journal.entry_date>=start))
    if end: q=q.filter(or_(Journal.id==None,Journal.entry_date<=end))
    if division: q=q.filter(or_(Journal.id==None,JournalLine.division_id==division))
    return q.group_by(Account.id).order_by(Account.code).all()

def paid_total(doc): return sum(p.amount_cents for p in doc.payments)
def outstanding(doc): return max(0,doc.total_cents-paid_total(doc))

@app.get('/')
def dashboard(request:Request):
    with SessionLocal() as db:
        a=account_balances(db)
        revenue=sum(int(c)-int(d) for _,_,_,k,d,c in a if k=='revenue')
        costs=sum(int(d)-int(c) for _,_,_,k,d,c in a if k=='expense')
        bank=journal_sum(db,'1000');cash=int(bank[0])-int(bank[1])
        pending=db.query(Invoice).filter(Invoice.status.in_(['issued','partial'])).all()
        outstanding_ar=sum(outstanding(x) for x in pending)
        recent=db.query(Journal).order_by(desc(Journal.entry_date),desc(Journal.id)).limit(7).all()
        latest=db.query(Invoice).order_by(desc(Invoice.id)).limit(5).all()
        ds=db.query(Division).order_by(Division.name).all()
        divdata=[]
        for d in ds:
            rows=account_balances(db,division=d.id)
            r=sum(int(c)-int(dr) for _,_,_,kind,dr,c in rows if kind=='revenue')
            ex=sum(int(dr)-int(c) for _,_,_,kind,dr,c in rows if kind=='expense')
            divdata.append({'name':d.name,'revenue':r,'expenses':ex,'profit':r-ex})
        # Latest six months, including authentic zero values.
        monthly=[]; now=today()
        for i in range(5,-1,-1):
            yy=now.year; mm=now.month-i
            while mm<=0: yy-=1;mm+=12
            lo=date(yy,mm,1);hi=date(yy+1,1,1) if mm==12 else date(yy,mm+1,1)
            q=db.query(Account.kind,func.coalesce(func.sum(JournalLine.debit_cents),0),func.coalesce(func.sum(JournalLine.credit_cents),0)).join(JournalLine,Account.id==JournalLine.account_id).join(Journal,Journal.id==JournalLine.journal_id).filter(Journal.entry_date>=lo,Journal.entry_date<hi, Account.kind.in_(['revenue','expense'])).group_by(Account.kind).all()
            rev=sum(int(cr)-int(dr) for k,dr,cr in q if k=='revenue');exp=sum(int(dr)-int(cr) for k,dr,cr in q if k=='expense')
            monthly.append({'month':lo.strftime('%b'),'revenue':rev,'expenses':exp})
        high=max([x['revenue'] for x in monthly]+[x['expenses'] for x in monthly]+[1])
        for m in monthly:
            m['revenue_height']=max(2,round(max(m['revenue'],0)/high*100));m['expense_height']=max(2,round(max(m['expenses'],0)/high*100))
        return render(request,'dashboard.html',nav='dashboard', revenue=revenue,costs=costs,profit=revenue-costs,cash=cash,
                      outstanding_ar=outstanding_ar,latest=latest,recent=recent,divdata=divdata,monthly=monthly,has_data=bool(recent))

@app.get('/contacts')
def contacts(request:Request,kind:str='customer',q:str=''):
    if kind not in ('customer','supplier'):kind='customer'
    with SessionLocal() as db:
        query=db.query(Contact).filter_by(kind=kind)
        if q: query=query.filter(Contact.name.ilike('%'+q[:90]+'%'))
        rows=query.order_by(Contact.name).limit(300).all()
        return render(request,'contacts.html',nav='customers' if kind=='customer' else 'suppliers', rows=rows,kind=kind,q=q)

@app.get('/contacts/{contact_id}/edit')
def contact_edit_page(request:Request,contact_id:int):
    require(request,'admin','accountant','staff')
    with SessionLocal() as db:
        c=db.get(Contact,contact_id)
        if not c:raise HTTPException(404,'Contact not found')
        return render(request,'contact_edit.html',nav='customers' if c.kind=='customer' else 'suppliers',contact=c)

@app.post('/contacts/{contact_id}/edit')
def contact_update(request:Request,contact_id:int,csrf:str=Form(...),name:str=Form(...),email:str=Form(''),phone:str=Form(''),address:str=Form(''),notes:str=Form('')):
    require(request,'admin','accountant','staff');check_csrf(request,csrf)
    with SessionLocal() as db:
        c=db.get(Contact,contact_id)
        if not c:raise HTTPException(404,'Contact not found')
        if not name.strip():raise HTTPException(400,'Enter a contact name')
        email=email.strip().lower()
        if email and db.query(Contact).filter(Contact.id!=contact_id,Contact.email==email,Contact.kind==c.kind).first():
            flash(request,'That email already exists for another contact.','error');return redirect(f'/contacts/{contact_id}/edit')
        c.name=name.strip()[:200];c.email=email[:200];c.phone=phone.strip()[:80];c.address=address.strip()[:3000];c.notes=notes.strip()[:2000]
        audit(db,request,'updated','contact',c.id,c.name);kind=c.kind;db.commit()
    flash(request,'Contact details saved.','success');return redirect('/contacts?kind='+kind)

@app.post('/contacts')
def save_contact(request:Request,csrf:str=Form(...),kind:str=Form(...),name:str=Form(...),
                 email:str=Form(''),phone:str=Form(''),address:str=Form(''),notes:str=Form('')):
    require(request,'admin','accountant','staff');check_csrf(request,csrf)
    if kind not in ('customer','supplier') or not name.strip(): raise HTTPException(400,'Enter valid contact details.')
    with SessionLocal() as db:
        if email.strip() and db.query(Contact).filter_by(kind=kind,email=email.strip().lower()).first():
            flash(request,'That email already exists for this contact type.','error');return redirect('/contacts?kind='+kind)
        c=Contact(kind=kind,name=name.strip()[:200],email=email.strip().lower()[:200],phone=phone.strip()[:80],address=address.strip()[:3000],notes=notes.strip()[:2000]);db.add(c);db.flush()
        audit(db,request,'created','contact',c.id,c.name);db.commit()
    flash(request,'Contact saved.','success'); return redirect('/contacts?kind='+kind)

@app.get('/divisions')
def divisions(request:Request):
    with SessionLocal() as db: rows=db.query(Division).order_by(Division.name).all()
    return render(request,'divisions.html',nav='divisions',rows=rows)

@app.post('/divisions')
def save_division(request:Request,csrf:str=Form(...),name:str=Form(...),code:str=Form(...)):
    require(request,'admin','accountant'); check_csrf(request,csrf)
    code=re.sub('[^A-Z0-9_-]','',code.upper())[:30]
    if not name.strip() or not code: raise HTTPException(400,'Enter division name and short code.')
    with SessionLocal() as db:
        try:
            d=Division(name=name.strip()[:150],code=code);db.add(d);db.flush();audit(db,request,'created','division',d.id,d.name);db.commit()
        except IntegrityError: db.rollback();flash(request,'Division name or code already exists.','error');return redirect('/divisions')
    flash(request,'Business division created.','success');return redirect('/divisions')

def invoice_form_context(db):
    return {'customers':db.query(Contact).filter_by(kind='customer').order_by(Contact.name).all(),
            'divisions':db.query(Division).filter_by(active=True).order_by(Division.name).all(),
            'setting':get_setting(db)}

@app.get('/invoices')
def invoices_page(request:Request,q:str='',status:str=''):
    with SessionLocal() as db:
        query=db.query(Invoice).join(Contact)
        if status in ('draft','issued','partial','paid','void'): query=query.filter(Invoice.status==status)
        if q:query=query.filter(or_(Invoice.number.ilike('%'+q[:100]+'%'),Contact.name.ilike('%'+q[:100]+'%')))
        rows=query.order_by(desc(Invoice.issued_on),desc(Invoice.id)).limit(300).all()
        return render(request,'invoices.html',nav='invoices',rows=rows,q=q,status=status,outstanding=outstanding)

@app.get('/invoices/new')
def invoice_new_page(request:Request):
    with SessionLocal() as db: ctx=invoice_form_context(db)
    return render(request,'invoice_new.html',nav='invoices',**ctx)

@app.post('/invoices/new')
async def invoice_new(request:Request):
    require(request,'admin','accountant','staff')
    form=await request.form();check_csrf(request,form.get('csrf'))
    try:
        customer_id=int(form['contact_id']);division_id=int(form['division_id']);issue=parse_date(form['issued_on']);due=parse_date(form['due_on'])
        if due<issue: raise ValueError('Due date cannot be before invoice date.')
        currency=str(form.get('currency','TTD')).upper()
        if currency not in ('TTD','USD','EUR','GBP','CAD'): raise ValueError('Unsupported currency.')
        rate=fx_value(form.get('fx_rate','1'),currency)
        tax_bps=int((D(form.get('tax_percent','0'))*100).quantize(Decimal('1')))
        if tax_bps < 0 or tax_bps > 10000: raise ValueError('Invalid VAT percentage.')
        entries=[]
        for i in range(1,9):
            desc_text=str(form.get(f'desc_{i}','')).strip()
            if not desc_text: continue
            qty=D(form.get(f'qty_{i}','1'))
            if qty<=0 or qty>100000 or not qty.is_finite():raise ValueError('Invalid quantity.')
            qty_1000=int((qty*1000).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
            unit=money_cents(form.get(f'unit_{i}','0'))
            amount=int((D(qty_1000)*unit/1000).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
            if amount<=0:raise ValueError('Invoice line amount must be positive.')
            entries.append((desc_text[:500],qty_1000,unit,amount))
        if not entries: raise ValueError('Add at least one invoice item.')
        subtotal=sum(x[3] for x in entries)
        vat=int((D(subtotal)*tax_bps/10000).quantize(Decimal('1'),rounding=ROUND_HALF_UP))
        with SessionLocal() as db:
            if not db.get(Contact,customer_id) or db.get(Contact,customer_id).kind!='customer':raise ValueError('Choose a customer.')
            if not db.get(Division,division_id):raise ValueError('Choose a division.')
            s=get_setting(db)
            obj=Invoice(number=next_number(db,'invoice',s.invoice_prefix),contact_id=customer_id,division_id=division_id,
                issued_on=issue,due_on=due,currency=currency,fx_rate=str(rate),
                bill_to_name=db.get(Contact,customer_id).name,bill_to_email=db.get(Contact,customer_id).email,bill_to_address=db.get(Contact,customer_id).address,
                issuer_name=s.company_name,issuer_email=s.business_email,issuer_address=s.address,issuer_registration=s.registration_number,issuer_vat_number=s.vat_number,
                subtotal_cents=subtotal,tax_bps=tax_bps,
                tax_cents=vat,total_cents=subtotal+vat,created_by=request.state.user.id,memo=str(form.get('memo',''))[:2000])
            db.add(obj);db.flush()
            for description,qty,unit,amount in entries:db.add(InvoiceLine(invoice_id=obj.id,description=description,quantity_thousandths=qty,unit_price_cents=unit,amount_cents=amount))
            audit(db,request,'created','invoice',obj.id,obj.number); db.commit()
            return redirect('/invoices/'+str(obj.id))
    except (ValueError,InvalidOperation,KeyError) as e:
        flash(request,str(e),'error');return redirect('/invoices/new')

@app.get('/invoices/{invoice_id}')
def invoice_detail(request:Request,invoice_id:int):
    with SessionLocal() as db:
        obj=db.get(Invoice,invoice_id)
        if not obj:raise HTTPException(404,'Invoice not found')
        return render(request,'invoice_detail.html',nav='invoices',invoice=obj,outstanding=outstanding(obj),payments=sorted(obj.payments,key=lambda p:p.paid_on,reverse=True))

@app.post('/invoices/{invoice_id}/issue')
def invoice_issue(request:Request,invoice_id:int,csrf:str=Form(...)):
    require(request,'admin','accountant');check_csrf(request,csrf)
    with SessionLocal() as db:
        obj=db.get(Invoice,invoice_id)
        if not obj or obj.status!='draft':raise HTTPException(400,'Only draft invoices can be issued.')
        rate=D(obj.fx_rate);net=base_cents(obj.subtotal_cents,rate);gross=base_cents(obj.total_cents,rate)
        vat=gross-net
        lines=[(account(db,'1100'),gross,0,obj.division_id),(account(db,'4000'),0,net,obj.division_id)]
        if vat:lines.append((account(db,'2100'),0,vat,obj.division_id))
        journal(db,obj.issued_on,f'Invoice {obj.number}','invoice',obj.id,lines,request.state.user.id)
        obj.status='issued';audit(db,request,'issued','invoice',obj.id,obj.number);db.commit()
    flash(request,'Invoice issued and recorded in the general ledger.','success');return redirect('/invoices/'+str(invoice_id))

@app.post('/invoices/{invoice_id}/void')
def invoice_void(request:Request,invoice_id:int,csrf:str=Form(...)):
    require(request,'admin','accountant');check_csrf(request,csrf)
    with SessionLocal() as db:
        obj=db.get(Invoice,invoice_id)
        if not obj or obj.status not in ('draft','issued') or obj.payments:raise HTTPException(400,'Only unpaid invoices can be voided.')
        if obj.status=='issued':
            orig=db.query(Journal).filter_by(source_type='invoice',source_id=obj.id).one()
            lines=[(ln.account_id,ln.credit_cents,ln.debit_cents,ln.division_id) for ln in orig.lines]
            journal(db,today(),f'Void {obj.number}','invoice_void',obj.id,lines,request.state.user.id,orig.id)
        obj.status='void';audit(db,request,'voided','invoice',obj.id,obj.number);db.commit()
    flash(request,'Invoice voided with an audit trail.','success');return redirect('/invoices/'+str(invoice_id))

@app.post('/invoices/{invoice_id}/payment')
def invoice_payment(request:Request,invoice_id:int,csrf:str=Form(...),amount:str=Form(...),paid_on:str=Form(...),
                    fx_rate:str=Form('1'),reference:str=Form('')):
    require(request,'admin','accountant');check_csrf(request,csrf)
    with SessionLocal() as db:
        obj=db.get(Invoice,invoice_id)
        if not obj or obj.status not in ('issued','partial'):raise HTTPException(400,'Invoice is not open for payment.')
        try:
            n=money_cents(amount)
            if n>outstanding(obj):raise ValueError('Payment cannot exceed outstanding balance.')
            date_paid=parse_date(paid_on)
            if date_paid<obj.issued_on: raise ValueError('Payment date cannot precede invoice issue date.')
            rate=fx_value(fx_rate,obj.currency)
            final=(n==outstanding(obj))
            booked_total=base_cents(obj.total_cents,obj.fx_rate)
            prev_book=sum(p.book_base_cents for p in obj.payments)
            booked=booked_total-prev_book if final else base_cents(n,obj.fx_rate)
            if booked<=0: raise ValueError('Payment too small for exchange-rate precision.')
            settled=base_cents(n,rate)
            lines=[(account(db,'1000'),settled,0,obj.division_id),(account(db,'1100'),0,booked,obj.division_id)]
            difference=settled-booked
            if difference>0: lines.append((account(db,'4900'),0,difference,obj.division_id))
            elif difference<0: lines.append((account(db,'5900'),-difference,0,obj.division_id))
            p=Payment(invoice_id=obj.id,amount_cents=n,book_base_cents=booked,settlement_base_cents=settled,fx_rate=str(rate),paid_on=date_paid,reference=reference[:120]);db.add(p);db.flush()
            journal(db,date_paid,f'Payment received for {obj.number}','customer_payment',p.id,lines,request.state.user.id)
            obj.status='paid' if final else 'partial';audit(db,request,'payment recorded','invoice',obj.id,f'{n} minor units / {obj.currency}');db.commit()
        except ValueError as e: flash(request,str(e),'error');return redirect('/invoices/'+str(invoice_id))
    flash(request,'Payment recorded and reconciled to receivables.','success');return redirect('/invoices/'+str(invoice_id))

@app.get('/invoices/{invoice_id}/pdf')
def invoice_pdf(request:Request,invoice_id:int):
    with SessionLocal() as db:
        obj=db.get(Invoice,invoice_id);s=get_setting(db)
        if not obj: raise HTTPException(404,'Invoice not found')
        buf=io.BytesIO();doc=SimpleDocTemplate(buf,pagesize=A4,rightMargin=45,leftMargin=45,topMargin=45,bottomMargin=45)
        styles=getSampleStyleSheet(); elems=[]
        elems.append(Paragraph(xml_escape(obj.issuer_name or s.company_name),styles['Title']))
        elems.append(Paragraph('INVOICE',styles['Heading2']))
        elems.append(Paragraph(f'<b>Invoice:</b> {obj.number} &nbsp;&nbsp; <b>Status:</b> {obj.status.upper()}',styles['Normal']))
        elems.append(Paragraph(f'<b>Issued:</b> {obj.issued_on} &nbsp;&nbsp; <b>Due:</b> {obj.due_on}',styles['Normal']))
        if obj.issuer_address: elems.append(Paragraph(xml_escape(obj.issuer_address).replace('\n','<br/>'),styles['Normal']))
        if obj.issuer_email: elems.append(Paragraph(xml_escape(obj.issuer_email),styles['Normal']))
        elems.append(Spacer(1,25));elems.append(Paragraph('<b>BILL TO</b>',styles['Normal']))
        elems.append(Paragraph(xml_escape(obj.bill_to_name or obj.contact.name),styles['Heading3']))
        if obj.bill_to_address:elems.append(Paragraph(xml_escape(obj.bill_to_address).replace('\n','<br/>'),styles['Normal']))
        elems.append(Spacer(1,22))
        rows=[['DESCRIPTION','QTY','UNIT PRICE','AMOUNT']]
        for ln in obj.lines: rows.append([xml_escape(ln.description),f'{ln.quantity_thousandths/1000:g}',f'{obj.currency} {cents(ln.unit_price_cents)}',f'{cents(ln.amount_cents)}'])
        rows += [['','','Subtotal',cents(obj.subtotal_cents)],['','','VAT',cents(obj.tax_cents)],['','','TOTAL '+obj.currency,cents(obj.total_cents)],['','','BALANCE DUE',cents(outstanding(obj))]]
        t=Table(rows,colWidths=[250,55,92,92],repeatRows=1)
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#14253e')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('ROWBACKGROUNDS',(0,1),(-1,-5),[colors.whitesmoke,colors.white]),('GRID',(0,0),(-1,-1),0.35,colors.HexColor('#e2e8ef')),('ALIGN',(1,1),(-1,-1),'RIGHT'),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),10),('FONTNAME',(2,-2),(-1,-2),'Helvetica-Bold')]))
        elems.append(t)
        if obj.memo: elems +=[Spacer(1,20),Paragraph('NOTES',styles['Heading4']),Paragraph(xml_escape(obj.memo).replace('\n','<br/>'),styles['Normal'])]
        doc.build(elems);buf.seek(0)
        return StreamingResponse(buf,media_type='application/pdf',headers={'Content-Disposition':f'attachment; filename="{obj.number}.pdf"'})

# Batch creation accepts CSV only, does not send emails. Dry-run validation before final create.
BATCH_FIELDS=['customer_email','division_code','shipment_reference','description','amount','currency','fx_rate','invoice_date','due_date']
@app.get('/invoices/batch/upload')
def batch_page(request:Request):return render(request,'batch.html',nav='batch',fields=BATCH_FIELDS)
@app.get('/invoices/batch/template')
def batch_template(request:Request):
    b=io.StringIO();csv.writer(b).writerow(BATCH_FIELDS)
    return Response(content=b.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="skybox_batch_template.csv"'})

@app.post('/invoices/batch/upload')
async def batch_upload(request:Request,file:UploadFile=File(...)):
    require(request,'admin','accountant');f=await request.form();check_csrf(request,f.get('csrf'))
    if not file.filename.lower().endswith('.csv'):flash(request,'Upload a CSV file using the supplied template.','error');return redirect('/invoices/batch/upload')
    raw=await file.read(2_000_001)
    if len(raw)>2_000_000:flash(request,'Maximum file size is 2 MB.','error');return redirect('/invoices/batch/upload')
    try: rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    except UnicodeError:flash(request,'Use a UTF-8 CSV file.','error');return redirect('/invoices/batch/upload')
    if not rows or len(rows)>1000:flash(request,'File must contain 1–1,000 rows.','error');return redirect('/invoices/batch/upload')
    if not set(BATCH_FIELDS).issubset(rows[0].keys()):flash(request,'CSV headers do not match the template.','error');return redirect('/invoices/batch/upload')
    errors=[];clean=[]
    with SessionLocal() as db:
        s=get_setting(db)
        for pos,row in enumerate(rows,2):
            try:
                email=(row.get('customer_email') or '').strip().lower()
                matches=db.query(Contact).filter(func.lower(Contact.email)==email,Contact.kind=='customer').all() if email else []
                if not matches:raise ValueError('Customer email not found. Add customer first.')
                if len(matches)!=1:raise ValueError('Customer email is ambiguous; correct duplicate customers first.')
                customer=matches[0]
                div=db.query(Division).filter(func.upper(Division.code)==(row.get('division_code') or '').strip().upper()).first()
                if not div:raise ValueError('Division code not found.')
                currency=(row.get('currency') or 'TTD').strip().upper()
                if currency not in ('TTD','USD','EUR','GBP','CAD'): raise ValueError('Unsupported currency.')
                rate=fx_value(row.get('fx_rate') or '1',currency)
                amount=money_cents(row['amount']);when=parse_date(row['invoice_date']);due=parse_date(row['due_date'])
                if due<when:raise ValueError('Due date precedes invoice date.')
                description=(row.get('description') or '').strip()
                if not description:raise ValueError('Description required.')
                clean.append({'customer':customer,'division':div,'currency':currency,'fx_rate':rate,'amount':amount,'issued':when,'due':due,
                              'description':description[:500],'reference':(row.get('shipment_reference') or '')[:120]})
            except (ValueError,KeyError,InvalidOperation) as e: errors.append(f'Row {pos}: {e}')
        if errors:
            return render(request,'batch.html',nav='batch',fields=BATCH_FIELDS,errors=errors[:40],error_count=len(errors))
        if f.get('mode')!='confirm':
            request.session['batch_digest']=hashlib.sha256(raw).hexdigest()
            return render(request,'batch.html',nav='batch',fields=BATCH_FIELDS,preview=clean[:10],total=len(clean),confirm=True)
        # Do not trust preview state: confirm must match the session-stored CSV exactly.
        if request.session.get('batch_digest')!=hashlib.sha256(raw).hexdigest():
            flash(request,'Upload and preview this batch before confirming.','error');return redirect('/invoices/batch/upload')
        try:
            for row in clean:
                inv=Invoice(number=next_number(db,'invoice',s.invoice_prefix),contact_id=row['customer'].id,
                            division_id=row['division'].id,issued_on=row['issued'],due_on=row['due'],currency=row['currency'],fx_rate=str(row['fx_rate']),
                            bill_to_name=row['customer'].name,bill_to_email=row['customer'].email,bill_to_address=row['customer'].address,
                            issuer_name=s.company_name,issuer_email=s.business_email,issuer_address=s.address,issuer_registration=s.registration_number,issuer_vat_number=s.vat_number,
                            subtotal_cents=row['amount'],tax_cents=0,total_cents=row['amount'],status='issued',
                            memo='Shipment reference: '+row['reference'],created_by=request.state.user.id)
                db.add(inv);db.flush();db.add(InvoiceLine(invoice_id=inv.id,description=row['description'],quantity_thousandths=1000,
                                                           unit_price_cents=row['amount'],amount_cents=row['amount']))
                amountbase=base_cents(row['amount'],row['fx_rate'])
                journal(db,inv.issued_on,f'Batch invoice {inv.number}','invoice',inv.id,
                        [(account(db,'1100'),amountbase,0,inv.division_id),(account(db,'4000'),0,amountbase,inv.division_id)],request.state.user.id)
            audit(db,request,'batch created','invoice',None,f'{len(clean)} invoices');db.commit()
        except Exception: db.rollback();raise
    request.session.pop('batch_digest',None)
    flash(request,f'{len(clean)} invoices issued and posted successfully.','success');return redirect('/invoices')

@app.get('/expenses')
def expenses_page(request:Request,q:str=''):
    with SessionLocal() as db:
        query=db.query(Expense)
        if q: query=query.filter(or_(Expense.number.ilike('%'+q[:100]+'%'),Expense.description.ilike('%'+q[:100]+'%')))
        rows=query.order_by(desc(Expense.posted_on),desc(Expense.id)).limit(300).all()
        return render(request,'expenses.html',nav='expenses',rows=rows,q=q,outstanding=outstanding)

@app.get('/expenses/new')
def expense_new(request:Request):
    with SessionLocal() as db:
        return render(request,'expense_new.html',nav='expenses',suppliers=db.query(Contact).filter_by(kind='supplier').order_by(Contact.name).all(),
                      divisions=db.query(Division).filter_by(active=True).order_by(Division.name).all(),
                      accounts=db.query(Account).filter_by(kind='expense',active=True).order_by(Account.code).all())

@app.post('/expenses/new')
def expense_save(request:Request,csrf:str=Form(...),contact_id:str=Form(''),division_id:int=Form(...),account_id:int=Form(...),
                 posted_on:str=Form(...),due_on:str=Form(...),description:str=Form(...),amount:str=Form(...),
                 currency:str=Form('TTD'),fx_rate:str=Form('1'),tax_percent:str=Form('0'),reference:str=Form('')):
    require(request,'admin','accountant');check_csrf(request,csrf)
    try:
        when=parse_date(posted_on);due=parse_date(due_on)
        if due<when:raise ValueError('Due date cannot precede expense date.')
        if currency not in ('TTD','USD','EUR','GBP','CAD'):raise ValueError('Invalid currency.')
        rate=fx_value(fx_rate,currency);cost=money_cents(amount)
        tax_bps=int((D(tax_percent)*100).quantize(Decimal('1')))
        if tax_bps<0 or tax_bps>10000:raise ValueError('Invalid VAT percentage.')
        tax=int((D(cost)*tax_bps/10000).quantize(Decimal('1'),rounding=ROUND_HALF_UP));total=cost+tax
        if not description.strip(): raise ValueError('Enter an expense description.')
        with SessionLocal() as db:
            div=db.get(Division,division_id);acc=db.get(Account,account_id)
            if not div or not acc or acc.kind!='expense':raise ValueError('Choose a valid division and expense category.')
            supplier=db.get(Contact,int(contact_id)) if contact_id else None
            if supplier and supplier.kind!='supplier':raise ValueError('Choose a supplier.')
            obj=Expense(number=next_number(db,'expense','BILL'),contact_id=supplier.id if supplier else None,
                division_id=division_id,account_id=account_id,posted_on=when,due_on=due,description=description.strip()[:500],
                reference=reference.strip()[:120],currency=currency,fx_rate=str(rate),supplier_name_snapshot=supplier.name if supplier else '',subtotal_cents=cost,tax_bps=tax_bps,
                tax_cents=tax,total_cents=total,created_by=request.state.user.id)
            db.add(obj);db.flush()
            base_total=base_cents(total,rate);base_cost=base_cents(cost,rate)
            lines=[(acc.id,base_cost,0,division_id),(account(db,'2000'),0,base_total,division_id)]
            if base_total-base_cost: lines.append((account(db,'1200'),base_total-base_cost,0,division_id))
            journal(db,when,f'Expense {obj.number}: {obj.description}','expense',obj.id,lines,request.state.user.id)
            audit(db,request,'created','expense',obj.id,obj.number);db.commit();return redirect('/expenses/'+str(obj.id))
    except (ValueError,InvalidOperation) as e:flash(request,str(e),'error');return redirect('/expenses/new')

@app.get('/expenses/{expense_id}')
def expense_detail(request:Request,expense_id:int):
    with SessionLocal() as db:
        exp=db.get(Expense,expense_id)
        if not exp:raise HTTPException(404,'Expense not found')
        return render(request,'expense_detail.html',nav='expenses',expense=exp,outstanding=outstanding(exp))

@app.post('/expenses/{expense_id}/payment')
def expense_payment(request:Request,expense_id:int,csrf:str=Form(...),amount:str=Form(...),paid_on:str=Form(...),fx_rate:str=Form('1'),reference:str=Form('')):
    require(request,'admin','accountant');check_csrf(request,csrf)
    with SessionLocal() as db:
        obj=db.get(Expense,expense_id)
        if not obj or obj.status not in ('posted','partial'):raise HTTPException(400,'Expense not available for payment.')
        try:
            n=money_cents(amount)
            if n>outstanding(obj):raise ValueError('Payment exceeds outstanding bill balance.')
            when=parse_date(paid_on)
            if when<obj.posted_on:raise ValueError('Payment date cannot precede bill date.')
            rate=fx_value(fx_rate,obj.currency)
            final=(n==outstanding(obj))
            original=base_cents(obj.total_cents,obj.fx_rate)
            booked=original-sum(p.book_base_cents for p in obj.payments) if final else base_cents(n,obj.fx_rate)
            if booked<=0:raise ValueError('Payment amount too small.')
            settled=base_cents(n,rate);difference=booked-settled
            lines=[(account(db,'2000'),booked,0,obj.division_id),(account(db,'1000'),0,settled,obj.division_id)]
            if difference>0:lines.append((account(db,'4900'),0,difference,obj.division_id))
            elif difference<0:lines.append((account(db,'5900'),-difference,0,obj.division_id))
            p=Payment(expense_id=obj.id,amount_cents=n,book_base_cents=booked,settlement_base_cents=settled,fx_rate=str(rate),paid_on=when,reference=reference[:120]);db.add(p);db.flush()
            journal(db,when,f'Payment made for {obj.number}','supplier_payment',p.id,lines,request.state.user.id)
            obj.status='paid' if final else 'partial';audit(db,request,'payment recorded','expense',obj.id,obj.number);db.commit()
        except ValueError as e:flash(request,str(e),'error');return redirect('/expenses/'+str(expense_id))
    flash(request,'Supplier payment posted.','success');return redirect('/expenses/'+str(expense_id))

@app.get('/employees')
def employees_page(request:Request):
    with SessionLocal() as db:
        return render(request,'employees.html',nav='employees',rows=db.query(Employee).order_by(Employee.full_name).all(),divisions=db.query(Division).all())

@app.post('/employees')
def employee_save(request:Request,csrf:str=Form(...),full_name:str=Form(...),code:str=Form(...),division_id:int=Form(...),job_title:str=Form('')):
    require(request,'admin','accountant');check_csrf(request,csrf)
    with SessionLocal() as db:
        if not db.get(Division,division_id):raise HTTPException(400,'Invalid division')
        try:
            obj=Employee(full_name=full_name.strip()[:180],code=code.strip().upper()[:40],division_id=division_id,job_title=job_title[:120]);db.add(obj);db.flush()
            audit(db,request,'created','employee',obj.id,obj.full_name);db.commit()
        except IntegrityError:db.rollback();flash(request,'Employee ID already exists.','error');return redirect('/employees')
    flash(request,'Employee added.','success');return redirect('/employees')

@app.get('/payroll')
def payroll_page(request:Request):
    with SessionLocal() as db:
        return render(request,'payroll.html',nav='payroll',rows=db.query(Payroll).order_by(desc(Payroll.pay_date),desc(Payroll.id)).limit(200).all(),
                      employees=db.query(Employee).filter_by(active=True).order_by(Employee.full_name).all(),period=today().strftime('%Y-%m'))

@app.post('/payroll')
def payroll_save(request:Request,csrf:str=Form(...),employee_id:int=Form(...),period:str=Form(...),pay_date:str=Form(...),
                 gross:str=Form(...),nis:str=Form('0'),paye:str=Form('0'),health:str=Form('0'),other:str=Form('0'),notes:str=Form('')):
    require(request,'admin','accountant');check_csrf(request,csrf)
    try:
        month_window(period);when=parse_date(pay_date)
        values=[money_cents(x,allow_zero=True) for x in (gross,nis,paye,health,other)];g,n,p,h,o=values
        if g<=0 or sum(values[1:])>g:raise ValueError('Deductions cannot exceed gross pay.')
        with SessionLocal() as db:
            emp=db.get(Employee,employee_id)
            if not emp:raise ValueError('Choose an employee.')
            obj=Payroll(employee_id=employee_id,period=period,pay_date=when,gross_cents=g,nis_cents=n,paye_cents=p,
                        health_cents=h,other_cents=o,net_cents=g-n-p-h-o,notes=notes[:1000]);db.add(obj);db.flush()
            lines=[(account(db,'5400'),g,0,emp.division_id)]
            if obj.net_cents:lines.append((account(db,'2200'),0,obj.net_cents,emp.division_id))
            if n+p+h+o:lines.append((account(db,'2210'),0,n+p+h+o,emp.division_id))
            journal(db,when,f'Payroll {period} / {emp.full_name}','payroll',obj.id,lines,request.state.user.id)
            audit(db,request,'created','payroll',obj.id,emp.full_name+' / '+period);db.commit()
    except IntegrityError:flash(request,'Payroll already recorded for this employee and month.','error');return redirect('/payroll')
    except ValueError as e:flash(request,str(e),'error');return redirect('/payroll')
    flash(request,'Payroll recorded. Deductions are manually entered; statutory calculations must be independently checked.','success')
    return redirect('/payroll')

@app.post('/payroll/{payroll_id}/pay')
def payroll_pay(request:Request,payroll_id:int,csrf:str=Form(...),paid_on:str=Form(...),reference:str=Form('')):
    require(request,'admin','accountant');check_csrf(request,csrf)
    with SessionLocal() as db:
        obj=db.get(Payroll,payroll_id)
        if not obj or obj.status!='unpaid':raise HTTPException(400,'Payroll already paid or not found')
        when=parse_date(paid_on)
        p=Payment(payroll_id=obj.id,amount_cents=obj.net_cents,book_base_cents=obj.net_cents,settlement_base_cents=obj.net_cents,fx_rate='1',paid_on=when,reference=reference[:120]);db.add(p);db.flush()
        journal(db,when,f'Net salary paid / {obj.employee.full_name}','payroll_payment',p.id,
                [(account(db,'2200'),obj.net_cents,0,obj.employee.division_id),(account(db,'1000'),0,obj.net_cents,obj.employee.division_id)],request.state.user.id)
        obj.status='paid';audit(db,request,'paid','payroll',obj.id,obj.employee.full_name);db.commit()
    flash(request,'Net salary payment recorded.','success');return redirect('/payroll')

@app.get('/reports')
def reports(request:Request,start:str='',end:str='',division_id:str=''):
    try:
        lo=parse_date(start) if start else date(today().year,1,1)
        hi=parse_date(end) if end else today()
        if hi<lo:raise ValueError('End date must be after start date.')
        div=int(division_id) if division_id.isdigit() else None
    except ValueError as e:flash(request,str(e),'error');return redirect('/reports')
    with SessionLocal() as db:
        dlist=db.query(Division).order_by(Division.name).all()
        pl=account_balances(db,start=lo,end=hi,division=div)
        rev=[{'code':code,'name':name,'amount':int(c)-int(d)} for _,code,name,k,d,c in pl if k=='revenue' and int(c)!=int(d)]
        exp=[{'code':code,'name':name,'amount':int(d)-int(c)} for _,code,name,k,d,c in pl if k=='expense' and int(d)!=int(c)]
        total_revenue=sum(x['amount'] for x in rev);total_exp=sum(x['amount'] for x in exp)
        bs=account_balances(db,end=hi)
        assets=sum(int(d)-int(c) for _,code,name,k,d,c in bs if k=='asset')
        liabilities=sum(int(c)-int(d) for _,code,name,k,d,c in bs if k=='liability')
        equity=sum(int(c)-int(d) for _,code,name,k,d,c in bs if k=='equity')
        accumulated_profit=sum((int(c)-int(d) if k=='revenue' else int(c)-int(d)) for _,code,name,k,d,c in bs if k in ('revenue','expense'))
        # Snapshot receivables/payables in base currency from posted journal balances,
        # rather than incorrectly summing nominal values across foreign currencies.
        def snapshot_balance(code):
            de, cr=journal_sum(db,code,through=hi)
            return int(de)-int(cr)
        unpaid_ar=snapshot_balance('1100');unpaid_ap=-snapshot_balance('2000')
        cash_open=snapshot_balance('1000')
        cash_rows=db.query(JournalLine.debit_cents,JournalLine.credit_cents,Journal.source_type).join(Journal,Journal.id==JournalLine.journal_id).join(Account,Account.id==JournalLine.account_id).filter(Account.code=='1000',Journal.entry_date>=lo,Journal.entry_date<=hi).all()
        inflows=sum(int(de) for de,cr,kind in cash_rows);outflows=sum(int(cr) for de,cr,kind in cash_rows);cash_begin=cash_open-inflows+outflows
        divisions=[]
        for dd in dlist:
            rows=account_balances(db,start=lo,end=hi,division=dd.id)
            rr=sum(int(c)-int(d) for _,_,_,k,d,c in rows if k=='revenue')
            ee=sum(int(d)-int(c) for _,_,_,k,d,c in rows if k=='expense')
            divisions.append({'division':dd,'income':rr,'cost':ee,'profit':rr-ee})
        tb=[]
        for _,code,name,k,de,cr in bs:
            bal=int(de)-int(cr)
            tb.append({'code':code,'name':name,'debit':max(0,bal),'credit':max(0,-bal)})
        return render(request,'reports.html',nav='reports',start=lo.isoformat(),end=hi.isoformat(),division_id=division_id,divisions_list=dlist,
                      revenues=rev,expenses=exp,total_revenue=total_revenue,total_exp=total_exp,profit=total_revenue-total_exp,
                      assets=assets,liabilities=liabilities,equity=equity,retained_profit=accumulated_profit,unpaid_ar=unpaid_ar,unpaid_ap=unpaid_ap,
                      classes=divisions,trial=tb,cash_begin=cash_begin,cash_in=inflows,cash_out=outflows,cash_end=cash_open)

@app.get('/ledger')
def ledger_page(request:Request,account_code:str='',start:str='',end:str=''):
    with SessionLocal() as db:
        q=db.query(JournalLine,Journal).join(Journal,Journal.id==JournalLine.journal_id).join(Account,Account.id==JournalLine.account_id)
        if account_code:q=q.filter(Account.code==account_code)
        if start:q=q.filter(Journal.entry_date>=parse_date(start))
        if end:q=q.filter(Journal.entry_date<=parse_date(end))
        rows=q.order_by(desc(Journal.entry_date),desc(Journal.id),desc(JournalLine.id)).limit(500).all()
        return render(request,'ledger.html',nav='ledger',rows=rows,account_code=account_code,start=start,end=end,
                      accounts=db.query(Account).order_by(Account.code).all())

@app.get('/journals/new')
def manual_journal_page(request:Request):
    require(request,'admin','accountant')
    with SessionLocal() as db:
        return render(request,'journal_new.html',nav='ledger',
                      accounts=db.query(Account).filter_by(active=True).order_by(Account.code).all(),
                      divisions=db.query(Division).filter_by(active=True).order_by(Division.name).all())

@app.post('/journals/new')
async def manual_journal_create(request:Request):
    require(request,'admin','accountant')
    f=await request.form();check_csrf(request,f.get('csrf'))
    try:
        when=parse_date(str(f.get('entry_date','')))
        description=str(f.get('description','')).strip()
        if len(description)<4:raise ValueError('Add an informative journal description.')
        rows=[]
        with SessionLocal() as db:
            for n in range(1,7):
                code=str(f.get(f'account_{n}','')).strip()
                if not code: continue
                acc=db.query(Account).filter_by(code=code,active=True).first()
                if not acc:raise ValueError(f'Invalid account on line {n}.')
                debit=money_cents(f.get(f'debit_{n}','0') or '0',allow_zero=True)
                credit=money_cents(f.get(f'credit_{n}','0') or '0',allow_zero=True)
                if (debit and credit) or not (debit or credit):raise ValueError(f'Line {n} must have one debit OR one credit.')
                div=int(f.get(f'division_{n}','0') or 0)
                if div and not db.get(Division,div):raise ValueError(f'Invalid division on line {n}.')
                rows.append((acc.id,debit,credit,div or None))
            if len(rows)<2:raise ValueError('Use at least two journal lines.')
            deb=sum(r[1] for r in rows);cr=sum(r[2] for r in rows)
            if deb!=cr:raise ValueError(f'This journal is not balanced. Debit TT$ {cents(deb)} / credit TT$ {cents(cr)}.')
            j=journal(db,when,description[:500],'manual',None,rows,request.state.user.id)
            audit(db,request,'manual journal posted','journal',j.id,j.reference+' / '+description)
            db.commit()
        flash(request,'Balanced journal posted successfully.','success');return redirect('/ledger')
    except (ValueError,InvalidOperation) as e:
        flash(request,str(e),'error');return redirect('/journals/new')

@app.post('/settings/users/{user_id}/deactivate')
def user_deactivate(request:Request,user_id:int,csrf:str=Form(...)):
    require(request,'admin');check_csrf(request,csrf)
    with SessionLocal() as db:
        u=db.get(User,user_id)
        if not u: raise HTTPException(404,'Unknown user')
        if u.id==request.state.user.id:raise HTTPException(400,'You cannot disable your own account.')
        if u.role=='admin' and db.query(User).filter_by(role='admin',active=True).count()<2:
            raise HTTPException(400,'At least one administrator must remain active.')
        u.active=False;audit(db,request,'deactivated','user',u.id,u.email);db.commit()
    flash(request,'User access disabled.','success');return redirect('/settings')

@app.get('/export/{kind}.csv')
def export(request:Request,kind:str):
    require(request,'admin','accountant','viewer') if request.state.user.role=='viewer' else require(request)
    buf=io.StringIO();w=csv.writer(buf)
    with SessionLocal() as db:
        if kind=='invoices':
            w.writerow(['Invoice','Customer','Division','Issued','Due','Currency','FX rate','Subtotal','VAT','Total','Paid','Status'])
            for i in db.query(Invoice).order_by(Invoice.id).all():w.writerow([i.number,i.bill_to_name or i.contact.name,i.division.name,i.issued_on,i.due_on,i.currency,i.fx_rate,cents(i.subtotal_cents),cents(i.tax_cents),cents(i.total_cents),cents(paid_total(i)),i.status])
        elif kind=='expenses':
            w.writerow(['Bill','Supplier','Division','Expense account','Posted','Due','Currency','FX rate','Total','Paid','Status'])
            for x in db.query(Expense).order_by(Expense.id).all():w.writerow([x.number,x.supplier_name_snapshot or '',x.division.name,x.account.name,x.posted_on,x.due_on,x.currency,x.fx_rate,cents(x.total_cents),cents(paid_total(x)),x.status])
        elif kind=='trial-balance':
            w.writerow(['Code','Account','Debit (TTD)','Credit (TTD)'])
            for _,code,name,k,de,cr in account_balances(db):
                bal=int(de)-int(cr);w.writerow([code,name,cents(max(0,bal)),cents(max(0,-bal))])
        elif kind=='journal':
            w.writerow(['Date','Journal','Description','Account','Division','Debit TTD','Credit TTD'])
            for ln,j in db.query(JournalLine,Journal).join(Journal).order_by(Journal.entry_date,Journal.id).all():
                w.writerow([j.entry_date,j.reference,j.description,ln.account.code,ln.division.name if ln.division else '',cents(ln.debit_cents),cents(ln.credit_cents)])
        else:raise HTTPException(404,'Unknown export')
    return Response(content='\ufeff'+buf.getvalue(),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="atlas-{kind}.csv"'})

@app.get('/settings')
def settings_page(request:Request):
    require(request,'admin')
    with SessionLocal() as db: users=db.query(User).order_by(User.id).all();logs=db.query(Audit).order_by(desc(Audit.id)).limit(50).all()
    return render(request,'settings.html',nav='settings',users=users,logs=logs)

@app.post('/settings/company')
def settings_company(request:Request,csrf:str=Form(...),company_name:str=Form(...),business_email:str=Form(''),
                     business_phone:str=Form(''),address:str=Form(''),registration_number:str=Form(''),
                     vat_number:str=Form(''),invoice_prefix:str=Form('INV'),tax_rate:str=Form('0')):
    require(request,'admin');check_csrf(request,csrf)
    try:
        bps=int((D(tax_rate)*100).quantize(Decimal('1')))
        if bps<0 or bps>10000:raise ValueError('VAT rate is invalid.')
        if not company_name.strip():raise ValueError('Enter a company name.')
        with SessionLocal() as db:
            s=get_setting(db);s.company_name=company_name.strip()[:180];s.business_email=business_email[:200];s.business_phone=business_phone[:80]
            s.address=address[:1500];s.registration_number=registration_number[:80];s.vat_number=vat_number[:80]
            s.invoice_prefix=re.sub('[^A-Z0-9-]','',invoice_prefix.upper())[:16] or 'INV';s.tax_rate_bps=bps
            audit(db,request,'updated','settings',1,'Company profile');db.commit()
    except ValueError as e:flash(request,str(e),'error');return redirect('/settings')
    flash(request,'Company settings updated. Base currency remains fixed as TTD.','success');return redirect('/settings')

@app.post('/settings/users')
def add_user(request:Request,csrf:str=Form(...),full_name:str=Form(...),email:str=Form(...),password:str=Form(...),role:str=Form(...)):
    require(request,'admin');check_csrf(request,csrf)
    if role not in ('admin','accountant','staff','viewer') or len(password)<12 or '@' not in email:
        flash(request,'Select a role, valid email, and a password of at least 12 characters.','error');return redirect('/settings')
    with SessionLocal() as db:
        try:
            u=User(full_name=full_name[:150],email=email.lower().strip()[:200],role=role,password_hash=ph.hash(password));db.add(u);db.flush()
            audit(db,request,'created','user',u.id,u.email);db.commit()
        except IntegrityError:db.rollback();flash(request,'That email is already registered.','error');return redirect('/settings')
    flash(request,'User account created.','success');return redirect('/settings')

@app.post('/settings/password')
def change_password(request:Request,csrf:str=Form(...),current_password:str=Form(...),new_password:str=Form(...)):
    require(request);check_csrf(request,csrf)
    if len(new_password)<12: flash(request,'New password must contain at least 12 characters.','error');return redirect('/profile')
    with SessionLocal() as db:
        u=db.get(User,request.state.user.id)
        try: ph.verify(u.password_hash,current_password)
        except (argonexc.VerifyMismatchError,argonexc.VerificationError):flash(request,'Current password is incorrect.','error');return redirect('/profile')
        u.password_hash=ph.hash(new_password);audit(db,request,'changed password','user',u.id,u.email);db.commit()
    flash(request,'Password updated.','success');return redirect('/profile')

@app.get('/profile')
def profile_page(request:Request):
    require(request)
    return render(request,'profile.html',nav='profile')

@app.get('/help')
def help_page(request:Request):return render(request,'help.html',nav='help')

app.add_middleware(SessionMiddleware, secret_key=SESSION_KEY, same_site='lax', https_only=os.getenv('COOKIE_SECURE','0')=='1', max_age=60*60*10)
initialize()
