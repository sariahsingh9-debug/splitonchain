from datetime import datetime, timezone
from sqlalchemy import create_engine, Column, Integer, String, Boolean, Date, DateTime, ForeignKey, Text, BigInteger, UniqueConstraint, Index
from sqlalchemy.orm import DeclarativeBase, relationship, sessionmaker
import os

class Base(DeclarativeBase): pass

def utcnow(): return datetime.now(timezone.utc).replace(tzinfo=None)

class Setting(Base):
    __tablename__ = 'settings'
    id = Column(Integer, primary_key=True)
    company_name = Column(String(180), nullable=False)
    business_email = Column(String(200), default='')
    business_phone = Column(String(80), default='')
    address = Column(Text, default='')
    base_currency = Column(String(3), default='TTD')
    registration_number = Column(String(80), default='')
    vat_number = Column(String(80), default='')
    invoice_prefix = Column(String(20), default='INV')
    tax_rate_bps = Column(Integer, default=0)
    created_at = Column(DateTime, default=utcnow)

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    full_name = Column(String(150), nullable=False)
    email = Column(String(200), nullable=False, unique=True, index=True)
    password_hash = Column(String(400), nullable=False)
    role = Column(String(20), nullable=False, default='staff')
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=utcnow)

class Division(Base):
    __tablename__ = 'divisions'
    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False, unique=True)
    code = Column(String(30), nullable=False, unique=True)
    active = Column(Boolean, default=True)

class Contact(Base):
    __tablename__ = 'contacts'
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    kind = Column(String(30), nullable=False, default='customer')
    email = Column(String(200), default='')
    phone = Column(String(80), default='')
    address = Column(Text, default='')
    notes = Column(Text, default='')
    created_at = Column(DateTime, default=utcnow)

class Account(Base):
    __tablename__ = 'accounts'
    id = Column(Integer, primary_key=True)
    code = Column(String(10), nullable=False, unique=True)
    name = Column(String(120), nullable=False)
    kind = Column(String(20), nullable=False)
    system = Column(Boolean, default=False)
    active = Column(Boolean, default=True)

class Invoice(Base):
    __tablename__ = 'invoices'
    id = Column(Integer, primary_key=True)
    number = Column(String(40), nullable=False, unique=True)
    contact_id = Column(Integer, ForeignKey('contacts.id'), nullable=False)
    division_id = Column(Integer, ForeignKey('divisions.id'), nullable=False)
    issued_on = Column(Date, nullable=False)
    due_on = Column(Date, nullable=False)
    currency = Column(String(3), default='TTD')
    fx_rate = Column(String(30), nullable=False, default='1')
    subtotal_cents = Column(BigInteger, default=0)
    tax_bps = Column(Integer, default=0)
    tax_cents = Column(BigInteger, default=0)
    total_cents = Column(BigInteger, default=0)
    status = Column(String(20), default='draft')
    memo = Column(Text, default='')
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=utcnow)
    bill_to_name = Column(String(200), default='')
    bill_to_email = Column(String(200), default='')
    bill_to_address = Column(Text, default='')
    issuer_name = Column(String(180), default='')
    issuer_email = Column(String(200), default='')
    issuer_address = Column(Text, default='')
    issuer_registration = Column(String(80), default='')
    issuer_vat_number = Column(String(80), default='')
    contact = relationship('Contact')
    division = relationship('Division')
    lines = relationship('InvoiceLine', cascade='all,delete-orphan', order_by='InvoiceLine.id')
    payments = relationship('Payment', primaryjoin="and_(Invoice.id == foreign(Payment.invoice_id))", viewonly=True)

class InvoiceLine(Base):
    __tablename__ = 'invoice_lines'
    id = Column(Integer, primary_key=True)
    invoice_id = Column(Integer, ForeignKey('invoices.id'), nullable=False)
    description = Column(String(500), nullable=False)
    quantity_thousandths = Column(Integer, default=1000)
    unit_price_cents = Column(BigInteger, nullable=False)
    amount_cents = Column(BigInteger, nullable=False)

class Expense(Base):
    __tablename__ = 'expenses'
    id = Column(Integer, primary_key=True)
    number = Column(String(40), nullable=False, unique=True)
    contact_id = Column(Integer, ForeignKey('contacts.id'), nullable=True)
    division_id = Column(Integer, ForeignKey('divisions.id'), nullable=False)
    account_id = Column(Integer, ForeignKey('accounts.id'), nullable=False)
    posted_on = Column(Date, nullable=False)
    due_on = Column(Date, nullable=False)
    description = Column(String(500), nullable=False)
    reference = Column(String(120), default='')
    currency = Column(String(3), default='TTD')
    fx_rate = Column(String(30), default='1')
    subtotal_cents = Column(BigInteger, nullable=False)
    tax_bps = Column(Integer, default=0)
    tax_cents = Column(BigInteger, default=0)
    total_cents = Column(BigInteger, nullable=False)
    status = Column(String(20), default='posted')
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=utcnow)
    supplier_name_snapshot = Column(String(200), default='')
    contact = relationship('Contact')
    division = relationship('Division')
    account = relationship('Account')
    payments = relationship('Payment', primaryjoin="and_(Expense.id == foreign(Payment.expense_id))", viewonly=True)

class Payment(Base):
    __tablename__ = 'payments'
    id = Column(Integer, primary_key=True)
    invoice_id = Column(Integer, ForeignKey('invoices.id'), nullable=True)
    expense_id = Column(Integer, ForeignKey('expenses.id'), nullable=True)
    payroll_id = Column(Integer, ForeignKey('payroll.id'), nullable=True)
    amount_cents = Column(BigInteger, nullable=False)
    book_base_cents = Column(BigInteger, nullable=False)
    settlement_base_cents = Column(BigInteger, nullable=False)
    fx_rate = Column(String(30), nullable=False, default='1')
    paid_on = Column(Date, nullable=False)
    reference = Column(String(120), default='')
    created_at = Column(DateTime, default=utcnow)

class Journal(Base):
    __tablename__ = 'journals'
    id = Column(Integer, primary_key=True)
    entry_date = Column(Date, nullable=False, index=True)
    reference = Column(String(80), nullable=False, unique=True)
    description = Column(String(500), nullable=False)
    source_type = Column(String(30), nullable=False)
    source_id = Column(Integer)
    reversal_of = Column(Integer, ForeignKey('journals.id'))
    created_by = Column(Integer, ForeignKey('users.id'))
    created_at = Column(DateTime, default=utcnow)
    lines = relationship('JournalLine', cascade='all,delete-orphan')

class JournalLine(Base):
    __tablename__ = 'journal_lines'
    id = Column(Integer, primary_key=True)
    journal_id = Column(Integer, ForeignKey('journals.id'), nullable=False, index=True)
    account_id = Column(Integer, ForeignKey('accounts.id'), nullable=False, index=True)
    division_id = Column(Integer, ForeignKey('divisions.id'), nullable=True)
    debit_cents = Column(BigInteger, default=0, nullable=False)
    credit_cents = Column(BigInteger, default=0, nullable=False)
    description = Column(String(300), default='')
    account = relationship('Account')
    division = relationship('Division')

class Employee(Base):
    __tablename__ = 'employees'
    id = Column(Integer, primary_key=True)
    full_name = Column(String(180), nullable=False)
    code = Column(String(40), nullable=False, unique=True)
    division_id = Column(Integer, ForeignKey('divisions.id'), nullable=False)
    job_title = Column(String(120), default='')
    active = Column(Boolean, default=True)
    division = relationship('Division')

class Payroll(Base):
    __tablename__ = 'payroll'
    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey('employees.id'), nullable=False)
    period = Column(String(7), nullable=False)
    pay_date = Column(Date, nullable=False)
    gross_cents = Column(BigInteger, nullable=False)
    nis_cents = Column(BigInteger, default=0)
    paye_cents = Column(BigInteger, default=0)
    health_cents = Column(BigInteger, default=0)
    other_cents = Column(BigInteger, default=0)
    net_cents = Column(BigInteger, nullable=False)
    status = Column(String(20), default='unpaid')
    notes = Column(Text, default='')
    created_at = Column(DateTime, default=utcnow)
    employee = relationship('Employee')
    __table_args__ = (UniqueConstraint('employee_id','period',name='uq_emp_period'),)

class Audit(Base):
    __tablename__ = 'audits'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    action = Column(String(100), nullable=False)
    subject = Column(String(100), nullable=False)
    subject_id = Column(Integer)
    summary = Column(String(500), default='')
    occurred_at = Column(DateTime, default=utcnow)
    user = relationship('User')

class NumberSequence(Base):
    __tablename__ = 'number_sequences'
    key = Column(String(30), primary_key=True)
    value = Column(Integer, default=0)

DEFAULT_ACCOUNTS = [
 ('1000','Bank & cash','asset'),('1100','Accounts receivable','asset'),('1200','Input VAT receivable','asset'),
 ('2000','Accounts payable','liability'),('2100','Sales VAT payable','liability'),
 ('2200','Payroll payable','liability'),('2210','Payroll deductions payable','liability'),
 ('3000','Opening equity','equity'),('3100','Retained earnings','equity'),
 ('4000','Service revenue','revenue'),('4100','Other revenue','revenue'),('4900','Realized FX gain','revenue'),
 ('5000','Operating expenses','expense'),('5100','Shipping & freight','expense'),('5200','Customs duties','expense'),
 ('5300','Transportation & fuel','expense'),('5400','Salaries & wages','expense'),('5500','Office & administration','expense'),
 ('5600','Other expenses','expense'),('5900','Realized FX loss','expense')
]

def make_engine():
    url = os.getenv('DATABASE_URL', 'sqlite:///./atlas_ledger.db')
    if url.startswith('postgres://'): url = 'postgresql+psycopg://' + url[len('postgres://'):]
    elif url.startswith('postgresql://'): url = 'postgresql+psycopg://' + url[len('postgresql://'):]
    kws = {'connect_args': {'check_same_thread':False}} if url.startswith('sqlite:') else {'pool_pre_ping':True}
    return create_engine(url, **kws)

engine = make_engine()
SessionLocal = sessionmaker(engine, expire_on_commit=False)

def initialize():
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        for code,name,kind in DEFAULT_ACCOUNTS:
            if not db.query(Account).filter_by(code=code).first(): db.add(Account(code=code,name=name,kind=kind,system=True))
        for key in ('invoice','expense'):
            if db.get(NumberSequence,key) is None:db.add(NumberSequence(key=key,value=0))
        db.commit()
