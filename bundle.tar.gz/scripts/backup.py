#!/usr/bin/env python3
"""Create an integrity-checked database backup.

Run from your private scheduled job (cron, Render cron job, etc.). Offsite copies must
be independently configured. No customer financial data is ever sent to ChatGPT.
"""
import os, sqlite3, gzip, hashlib, shutil, subprocess, sys, json
from pathlib import Path
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse

ROOT=Path(__file__).resolve().parents[1]
DEST=Path(os.getenv('BACKUP_DEST',str(ROOT/'backups'))).resolve()
RETENTION_DAYS=int(os.getenv('BACKUP_RETENTION_DAYS','30'))
URL=os.getenv('DATABASE_URL','sqlite:///./atlas_ledger.db')

def backup():
    if RETENTION_DAYS < 7:raise RuntimeError('BACKUP_RETENTION_DAYS must be at least 7.')
    DEST.mkdir(parents=True,exist_ok=True)
    if DEST.is_symlink():raise RuntimeError('Backup path cannot be a symlink.')
    name='atlas-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    tmp=DEST/(name+'.working')
    try:
        if URL.startswith('sqlite:///'):
            path=URL[len('sqlite:///'):]
            dbfile=Path(path)
            if not dbfile.is_absolute():dbfile=ROOT/dbfile
            if not dbfile.is_file():raise RuntimeError('Database does not exist; no backup was created.')
            dest=DEST/(name+'.sqlite3.gz')
            # SQLite online backup API produces a consistent point-in-time snapshot.
            with sqlite3.connect(str(dbfile)) as src,sqlite3.connect(str(tmp)) as dst:
                src.backup(dst)
                ok=dst.execute('PRAGMA integrity_check').fetchone()[0]
                if ok!='ok':raise RuntimeError('SQLite backup integrity check failed: '+ok)
            with open(tmp,'rb') as inp,gzip.open(dest,'wb',compresslevel=6) as out:shutil.copyfileobj(inp,out)
        elif URL.startswith(('postgres://','postgresql://','postgresql+psycopg://')):
            dest=DEST/(name+'.postgres.dump')
            plain=URL.replace('postgresql+psycopg://','postgresql://',1).replace('postgres://','postgresql://',1)
            # pg_dump uses its own SSL/credentials handling. Use DATABASE_URL from secret store.
            result=subprocess.run(['pg_dump','--format=custom','--file',str(tmp),'--dbname',plain],capture_output=True,text=True,timeout=1800)
            if result.returncode:raise RuntimeError('pg_dump failed: '+result.stderr[-2000:])
            os.replace(tmp,dest)
        else:raise RuntimeError('Unsupported DATABASE_URL for automated backups.')
        digest=hashlib.sha256(dest.read_bytes()).hexdigest()
        (DEST/(dest.name+'.sha256')).write_text(digest+'  '+dest.name+'\n')
        cutoff=datetime.now(timezone.utc)-timedelta(days=RETENTION_DAYS)
        for file in DEST.glob('atlas-*'):
            if file.is_file() and datetime.fromtimestamp(file.stat().st_mtime,timezone.utc)<cutoff: file.unlink()
        print(json.dumps({'status':'success','backup':str(dest),'sha256':digest,'bytes':dest.stat().st_size,'offsite_copy':'NOT CONFIGURED BY THIS SCRIPT'}))
    finally:
        if tmp.exists():tmp.unlink()

if __name__=='__main__':
    try:backup()
    except Exception as exc:
        print('BACKUP FAILED:',str(exc),file=sys.stderr)
        sys.exit(1)
