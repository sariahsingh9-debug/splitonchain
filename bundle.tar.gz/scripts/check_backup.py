#!/usr/bin/env python3
"""Check checksum and SQLite content integrity without overwriting a live database."""
import sys,hashlib,sqlite3,gzip,tempfile,shutil
from pathlib import Path

def verify(path):
    path=Path(path); sha=path.with_name(path.name+'.sha256')
    if not sha.exists():raise RuntimeError('Missing checksum file')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    if sha.read_text().split()[0]!=digest:raise RuntimeError('Backup checksum mismatch')
    if path.name.endswith('.sqlite3.gz'):
        with tempfile.TemporaryDirectory() as tmp:
            candidate=Path(tmp)/'restore.sqlite3'
            with gzip.open(path,'rb') as z,open(candidate,'wb') as f:shutil.copyfileobj(z,f)
            with sqlite3.connect(str(candidate)) as db:
                if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('SQLite integrity check failed')
                expected={'settings','users','invoices','journals','journal_lines'}
                actual={r[0] for r in db.execute('SELECT name FROM sqlite_master WHERE type="table"')}
                if not expected.issubset(actual):raise RuntimeError('Required tables missing')
    print('Backup passed integrity and checksum checks:',path)

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python scripts/check_backup.py /path/to/backup')
    try:verify(sys.argv[1])
    except Exception as exc:raise SystemExit('Backup verification failed: '+str(exc))
