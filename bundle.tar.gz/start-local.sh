#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
: "${SETUP_TOKEN:?Export SETUP_TOKEN before running.}"
: "${SESSION_SECRET:?Export SESSION_SECRET before running.}"
uvicorn app:app --host 127.0.0.1 --port 8000
