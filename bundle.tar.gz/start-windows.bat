@echo off
cd /d "%~dp0"
if not exist .venv (python -m venv .venv)
call .venv\Scripts\activate.bat
python -m pip install -r requirements.txt
if "%SETUP_TOKEN%"=="" (
  echo.
  echo Please set SETUP_TOKEN and SESSION_SECRET first.
  echo Example: set SETUP_TOKEN=your-long-setup-key
  echo Example: set SESSION_SECRET=your-64-character-secret
  pause
  exit /b 1
)
python -m uvicorn app:app --host 127.0.0.1 --port 8000
