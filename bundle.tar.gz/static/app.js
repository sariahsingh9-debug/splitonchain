(() => {
  const sidebar=document.getElementById('sidebar');
  const backdrop=document.getElementById('backdrop');
  const open=document.getElementById('open-menu');
  const close=document.getElementById('close-menu');
  const toggle=(state)=>{sidebar?.classList.toggle('open',state);backdrop?.classList.toggle('open',state);};
  open?.addEventListener('click',()=>toggle(true));
  close?.addEventListener('click',()=>toggle(false));
  backdrop?.addEventListener('click',()=>toggle(false));
  document.querySelectorAll('[data-modal]').forEach(b=>b.addEventListener('click',()=>document.getElementById(b.dataset.modal)?.showModal()));
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>b.closest('dialog')?.close()));
  document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)d.close();}));
  document.querySelectorAll('form[data-confirm]').forEach(f=>f.addEventListener('submit',e=>{if(!confirm(f.dataset.confirm))e.preventDefault();}));
  document.querySelectorAll('[data-confirm-click]').forEach(b=>b.addEventListener('click',e=>{if(!confirm(b.dataset.confirmClick))e.preventDefault();}));
  const currency=document.getElementById('currency');
  const fx=document.getElementById('fx-rate');
  currency?.addEventListener('change',()=>{if(currency.value==='TTD'){fx.value='1';fx.readOnly=true;}else{fx.readOnly=false;fx.value='';fx.focus();}});
  if(currency?.value==='TTD'&&fx)fx.readOnly=true;
})();
